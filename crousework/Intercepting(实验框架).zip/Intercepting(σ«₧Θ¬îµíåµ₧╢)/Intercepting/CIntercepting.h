#pragma once
#include "..\framework\game.h"
#include <list>
#include <stdio.h> 
#include<math.h>

using namespace std;

#define DIRECTINPUT_VERSION 0x0800  // let compile shut up
#define PI 3.1415926

enum DIR
{
	NONE,
	LEFT,
	RIGHT,
	UP,
	DOWN,
	LEFT_UP,
	RIGHT_UP,
	LEFT_DOWN,
	RIGHT_DOWN
};

enum STATE
{
	STAND,
	BASECHASING,
	LINEOFSIGHTCHASING,
	CHASINGWITHVECTOR,
};

class CIntercepting  :	public CGame
{
public:
	CIntercepting (HINSTANCE hInst,HWND hWnd,bool bWindowed = true,int nFps = 0);
	~CIntercepting (void);
	void InitGame();
	void GameFunc(float fDeltaTime);

	
private:
	CAnimationSprite *pUFO;
	CAnimationSprite *pExplosion;
	CSprite *pMissile;
	CTextSprite * pPrompt;


	D3DXVECTOR3 vpUFOOld;							//��һ֡UFO��λ��
	D3DXVECTOR3 vvUFO;								//UFO���ٶ�

	//float fMissileSpeed;							//�������ٶȴ�С
	//float fMissileAngle;							//�����ķ��нǶ�
	D3DXVECTOR3 vvMissile;							//�������ٶ�

	float g;											//�������ٶ�

	void Reset();
	void UpdateUFO(float fDeltaTime);		
	void UpdateMissile(float fDeltaTime);
	void UpdateExplosion(float fDeltaTime);
};
