#include "Game.h"
	
CGame::CGame(HWND hWnd,bool bWindowed,int nFps,HINSTANCE hInst)
{
	this->nFps = nFps;
	this->hWnd = hWnd;

	if (hInst == NULL)
	{
		hInst = GetModuleHandle(NULL);
	}
	this->hInstance = hInst;

	if (nFps > 0)
	{
		nFixedDeltaTime = 1000 / nFps;
	}
	else
	{
		nFixedDeltaTime = 0;
	}
	this->bWindowed = bWindowed;
	
	pResManager = 0;
	pSpriteManager = 0;
	pD3D = 0;
	pD3DDevice = 0;
	pFPSTextSprite = 0;
	Init3D(hWnd);
	
	
	t=0;
	nFrames = 0;
	
	t0 = timeGetTime();
	

	pDInput = 0;
	pKeyboard = 0;
	pMouse = 0;
	InitDInput(hInstance,hWnd);

}

CGame::~CGame(void)												//�������������ͷ���Դ
{
	if (pSpriteManager)
	{
		delete pSpriteManager;
	}
	if (pResManager)
	{
		delete pResManager;
	}
	
	Cleanup();

	ReleaseInput();

}


HRESULT CGame::Init3D(HWND hWnd)
{

    // Create the D3D object, which is needed to create the D3DDevice.
    if( NULL == ( pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    this->hWnd = hWnd;

	
	
   	// Set up the structure used to create the D3DDevice. Most parameters are
    // zeroed out. We set Windowed to TRUE, since we want to do D3D in a
    // window, and then set the SwapEffect to "discard", which is the most
    // efficient method of presenting the back buffer to the display.  And 
    // we request a back buffer format that matches the current desktop display 
    // format.

	GetClientRect(hWnd,&rectClient);
   
	D3DCAPS9 caps;
	
	pD3D->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &caps);

	D3DDISPLAYMODE d3ddm;															//�õ���ǰ�Կ�ģʽ
    if(FAILED(pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm)))
    {
        return E_FAIL;
    }


	int vp = 0;
	if( caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT )
		vp = D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		vp = D3DCREATE_SOFTWARE_VERTEXPROCESSING;

    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = bWindowed;
    
	if (!bWindowed)
	{
		ShowWindow(hWnd,SW_HIDE);
		d3dpp.BackBufferFormat           = d3ddm.Format;
		d3dpp.BackBufferCount            = 1;
		d3dpp.BackBufferWidth = d3ddm.Width;//rectClient.right - rectClient.left;
		d3dpp.BackBufferHeight = d3ddm.Height;// rectClient.bottom - rectClient.top;
		d3dpp.hDeviceWindow = hWnd;
		
		d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
		d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

		d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;

		SetWindowLong( hWnd, GWL_STYLE, WS_POPUP|WS_SYSMENU );

		rectClient.right = rectClient.left + d3ddm.Width;
		rectClient.bottom = rectClient.top + d3ddm.Height;
	}
	else
	{
		d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;////D3DSWAPEFFECT_COPY;//D3DSWAPEFFECT_DISCARD;
		d3dpp.BackBufferFormat = d3ddm.Format;//D3DFMT_UNKNOWN;
		
	}
	
	if(pD3D->CheckDeviceFormat(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format, D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D32) == D3D_OK)
	{
        d3dpp.AutoDepthStencilFormat = D3DFMT_D32;
        d3dpp.EnableAutoDepthStencil = TRUE;

	
    }
    else if(pD3D->CheckDeviceFormat(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format, D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D24X8) == D3D_OK)
    {
		d3dpp.AutoDepthStencilFormat = D3DFMT_D24X8;
        d3dpp.EnableAutoDepthStencil = TRUE;

	
	}
    else if(pD3D->CheckDeviceFormat(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format, D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D16) == D3D_OK)
    {
		d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
        d3dpp.EnableAutoDepthStencil = TRUE;

	
	}
    else
	{
        d3dpp.EnableAutoDepthStencil = FALSE;
	
	}



    // Create the Direct3D device. Here we are using the default adapter (most
    // systems only have one, unless they have multiple graphics hardware cards
    // installed) and requesting the HAL (which is saying we want the hardware
    // device rather than a software one). Software vertex processing is 
    // specified since we know it will work on all cards. On cards that support 
    // hardware vertex processing, though, we would see a big performance gain 
    // by specifying hardware vertex processing.

    if( FAILED( pD3D->CreateDevice(	D3DADAPTER_DEFAULT, 
									D3DDEVTYPE_HAL, hWnd,
                                    vp,
                                    &d3dpp, 
									&pD3DDevice ) ) )
    {
        return E_FAIL;
    }
	

	CreateResourceManager(pD3DDevice);
	CreateSpriteManager(pD3DDevice);

	pFPSTextSprite = new CTextSprite(pD3DDevice,D3DXVECTOR3(10,10,0),TEXT("����"),20,true,false,false);
	SetupDeviceState();

	
    return S_OK;
}
HRESULT CGame::Restore()
{
	if (pFPSTextSprite)
	{
		delete pFPSTextSprite;
		pFPSTextSprite = 0;
	}
	
	pSpriteManager->Release();
	HRESULT ret = pD3DDevice->Reset(&d3dpp);
	if (SUCCEEDED(ret))
	{
		pSpriteManager->Restore(pD3DDevice);
		pFPSTextSprite = new CTextSprite(pD3DDevice,D3DXVECTOR3(10,10,0),TEXT("����"),20,true,false,false);
		SetupDeviceState();
	}
	return ret;
}

void CGame::SetupDeviceState()
{
	SetupViewer();
	SetupProjection();
	pD3DDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,   TRUE);
	pD3DDevice->SetRenderState(D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA);
    pD3DDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	pD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);	
	pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
}
void CGame::CreateSpriteManager(LPDIRECT3DDEVICE9)
{
	pSpriteManager =  new CSpriteManager(pD3DDevice,pResManager);
}
void CGame::CreateResourceManager(LPDIRECT3DDEVICE9 pD3DDevice)
{
	pResManager = new CResourceManager(pD3DDevice);
}


//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
void CGame::Cleanup()
{
    if( pD3DDevice != NULL) 
        pD3DDevice->Release();

    if( pD3D != NULL)
        pD3D->Release();
	if (pFPSTextSprite != NULL)
	{
		delete pFPSTextSprite;
	}
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
void CGame::Render()
{
    if( NULL == pD3DDevice )
        return;

	
    // Clear the backbuffer to a blue color
	D3DCOLOR color = D3DCOLOR_XRGB (0,0,0);//rand()%255,rand()%255,rand()%255);
    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, color, 1.0f, 0 );
    
    // Begin the scene
    if( SUCCEEDED( pD3DDevice->BeginScene() ) )
    {
        // Rendering of scene objects can happen here
		if (pSpriteManager)
		{
			pSpriteManager->Render();
		}

		if (t > 0)
		{
			int nfps =  nFrames / t;
			wsprintf(szBuf,TEXT("%d"),nfps);
			pFPSTextSprite->SetText(szBuf);
			pFPSTextSprite->Render();
		}
    
        // End the scene
        pD3DDevice->EndScene();
    }

    // Present the backbuffer contents to the display
   devState = pD3DDevice->Present( NULL, NULL, NULL, NULL );
}
void CGame::Update()
{
	DWORD dt = 0;
	
	do 
	{ 
		dt=timeGetTime() - t0; 
	} while(dt < 1);									//��֤��С���ʱ����ڵ���1����
	if (dt >= nFixedDeltaTime)							//������ڹ̶��ļ��ʱ��
	{
		
		t0 = timeGetTime();								//��¼��֡���õ�ʱ��
		if (devState != D3D_OK)
		{
			HRESULT hr = pD3DDevice->TestCooperativeLevel();
			if (hr == D3DERR_DEVICELOST) 
			{
				Sleep(1);		
				return ;
			}
			else if (hr == D3DERR_DEVICENOTRESET)
			{
				if(FAILED(Restore()))
				{
					Sleep(1);		
					return;
				}
				
			}
		}
		
		ReadKeyboard();
		ReadMouse();

		GameFunc(dt / 1000.0);							//����֡��������
		t += dt / 1000.0;
		Render();										//��Ⱦ
		if (t > 1)
		{
			t = 0;
			nFrames = 0;
		}
		nFrames++;
	}
	else
	{
		Sleep(1);										//��������1����
	}
	
}

void CGame::GameFunc(float fDeltaTime)
{
	pSpriteManager->Update(fDeltaTime);					//֡����������ϵͳ���ŵ�ʱ�����������ľ��飬�������������أ�д��Ϸ����
}

void CGame::SetupViewer()
{
	if (pD3DDevice)
	{
		D3DXMatrixIdentity(&matView);
		
		pD3DDevice->SetTransform(D3DTS_VIEW,&matView);
	}
	
}
void CGame::SetupProjection()
{
	if (pD3DDevice)
	{

		D3DXMatrixOrthoOffCenterLH(	&matProj, 
									0.0f,
									(float)rectClient.right,
									(float)rectClient.bottom,
									(float)rectClient.top,
									0.0f, 
									100.0f);


		
		pD3DDevice->SetTransform(D3DTS_PROJECTION,&matProj);
	}
}
void CGame::OnSize(WPARAM wParam, LPARAM lParam)
{
	
}


void CGame::InitDInput(HINSTANCE hInstance,HWND hWnd)
{
	if(FAILED(DirectInput8Create(hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**) &pDInput, NULL)))
	{
		//MessageBox(NULL, TEXT("Create Directinput object failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return ;
	}
	CreateKeyboard(hWnd);
	CreateMouse(hWnd);


}
bool CGame::CreateKeyboard(HWND hWnd)
{
	if(FAILED(pDInput->CreateDevice(GUID_SysKeyboard, &pKeyboard, NULL)))
	{
		//MessageBox(NULL, TEXT("DirectInput interface create failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	if(FAILED(pKeyboard->SetDataFormat(&c_dfDIKeyboard)))
	{
		//MessageBox(NULL, TEXT("Set data format with keyboard read mode failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	if(FAILED(pKeyboard->SetCooperativeLevel(hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
	{
		//MessageBox(NULL, TEXT("Set cooperative Leve failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}
	if(FAILED(pKeyboard->Acquire()))
	{
		//MessageBox(NULL, TEXT("Acquire keyboard access failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	// zero keyboard buffer
	ZeroMemory(keyBuffer, sizeof(keyBuffer));
	ZeroMemory(oldKeyBuffer,sizeof(char) * 256);
	return true;
}
bool CGame::CreateMouse(HWND hWnd)
{
	// create mouse input device
	if(FAILED(pDInput->CreateDevice(GUID_SysMouse, &pMouse, NULL)))
	{
		//MessageBox(NULL, TEXT("Create mouse input device failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	// set data format for mouse
	if(FAILED(pMouse->SetDataFormat(&c_dfDIMouse)))
	{
		//MessageBox(NULL, TEXT("Set mouse data format failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	// set cooperative level for mouse
	if(FAILED(pMouse->SetCooperativeLevel(hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
	{
		//MessageBox(NULL, TEXT("Set mouse cooperative level failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	// set property for mouse
	DIPROPDWORD device_prop;

	device_prop.diph.dwSize       = sizeof(DIPROPDWORD);
	device_prop.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	device_prop.diph.dwObj        = 0;
	device_prop.diph.dwHow        = DIPH_DEVICE;
	device_prop.dwData            = ITEMS_NUM;

	if(FAILED(pMouse->SetProperty(DIPROP_BUFFERSIZE, &device_prop.diph)))
	{
		//MessageBox(NULL, TEXT("Set property for mouse failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	// get access to mouse
	if(FAILED(pMouse->Acquire()))
	{
		//MessageBox(NULL, TEXT("Get access to mouse failed."), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
		return false;
	}

	return true;
}

bool CGame::ReadKeyboard()
{
	if (!pKeyboard)
	{
		return false;
	}
	//if(DIERR_INPUTLOST == pKeyboard->GetDeviceState(sizeof(keyBuffer), (LPVOID) keyBuffer))
	if(FAILED(pKeyboard->GetDeviceState(sizeof(keyBuffer), (LPVOID) keyBuffer)))
	{
		// re-acquire access to keyboard
		pKeyboard->Acquire();

		if(FAILED(pKeyboard->GetDeviceState(sizeof(keyBuffer), (LPVOID) keyBuffer)))
			return false;
	}

	return true;
}
bool CGame::ReadMouse()
{
	if (!pMouse)
	{
		return false;
	}
	DWORD read_num = 1;

	// zero mouse buffer before reading data 
	ZeroMemory(mouseBuffer, sizeof(DIDEVICEOBJECTDATA) * ITEMS_NUM);

	// read all mouse data from buffer
	for(int i = 0; i < ITEMS_NUM; i++)
	{
		//if(DIERR_INPUTLOST == pMouse->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), &mouseBuffer[i], &read_num, 0))
		if(FAILED(pMouse->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), &mouseBuffer[i], &read_num, 0)))
		{
			pMouse->Acquire();

			if(FAILED(pMouse->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), &mouseBuffer[i], &read_num, 0)))
				return false;
		}

	/*	if(mouseBuffer[i].dwOfs == DIMOFS_X)
			mouseMoveX += mouseBuffer[i].dwData;

		if(mouseBuffer[i].dwOfs == DIMOFS_Y)
			mouseMoveY += mouseBuffer[i].dwData;        */
	}

	return true;
}

bool CGame::IsKeyPressed(int key)    
{ 
	return (keyBuffer[key] & 0x80 ? true : false); 
}
bool CGame::IsKeyUp(int key)
{
	bool bRet = false;
	if (keyBuffer[key] == oldKeyBuffer[key])
	{

		bRet = false;
	}
	else
	{


		if (keyBuffer[key] & 0x80)
		{

			bRet = true;
		}
		else
		{

			bRet = false;
		}
		memcpy(oldKeyBuffer,keyBuffer,sizeof(oldKeyBuffer));
	}
	return bRet;

}



void CGame::ReleaseInput()
{
	if(pKeyboard)
		pKeyboard->Unacquire();

	if(pMouse)
		pMouse->Unacquire();

	Safe_Release(pKeyboard);
	Safe_Release(pMouse);


	Safe_Release(pDInput);
}
