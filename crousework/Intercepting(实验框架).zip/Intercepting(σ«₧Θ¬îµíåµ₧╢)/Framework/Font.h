// Font.h: interface for the CFont class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FONT_H__656AEF3D_35E9_40F5_AFB6_D1BEA7A6BF37__INCLUDED_)
#define AFX_FONT_H__656AEF3D_35E9_40F5_AFB6_D1BEA7A6BF37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "sprite.h"

class CFont //: public CSprite 
{
public:
	void DrawText(LPCWSTR pText, int x, int y, D3DCOLOR rgbFontColour);
	CFont(LPDIRECT3DDEVICE9 pD3DDevice, LPCWSTR pFontFace, int nHeight, bool fBold, bool fItalic, bool fUnderlined);
	virtual ~CFont();
private:
	LPDIRECT3DDEVICE9	pD3DDevice;
	LPD3DXFONT			pFont;
};

#endif // !defined(AFX_FONT_H__656AEF3D_35E9_40F5_AFB6_D1BEA7A6BF37__INCLUDED_)
