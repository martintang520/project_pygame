#include "AnimationSprite.h"



CAnimationSprite::~CAnimationSprite(void)
{
}
CAnimationSprite::CAnimationSprite(	LPDIRECT3DDEVICE9	pD3DDevice,
									const LPCWSTR				pszName,
									LPDIRECT3DTEXTURE9	pTexture,
									D3DXVECTOR3			vPos,
									int					nFrames,
									int					nFps,
									int					width,
									int					height,
									int					tx,
									int					ty,
									D3DXVECTOR3			vHotSpot
								):CSprite(pD3DDevice,pszName,pTexture,vPos,width,height,tx,ty,vHotSpot)
{
	this->nFrames = nFrames;
	this->nFps = nFps;
	D3DSURFACE_DESC surfaceDesc;
	pTexture->GetLevelDesc(0,&surfaceDesc);
	this->nTexWidth =  surfaceDesc.Width;
	this->nTexHeight  = surfaceDesc.Height;
	
	this->vPos = vPos;
	txStart = tx;
	tyStart = ty;
	bPlaying = false;
	nMode = ANI_FWD | ANI_LOOP;
	this->fInterval = 1.0f/nFps;
}

//���ݲ���ģʽ���ö������ŵĳ�ʼ����
void CAnimationSprite::Play() 
{
	bPlaying=true;
	fSinceLastFrame=-1.0f;
	if(nMode == ANI_REV)
	{
		nDelta = -1;
		SetFrame(nFrames-1);
	}
	else
	{
		nDelta = 1;
		SetFrame(0);
	}
}
//����ϵͳ���ŵ�ʱ�������¶���
void CAnimationSprite::Update(float fDeltaTime)
{
	if(!bPlaying) 
	{
		return;
	}

	if(fSinceLastFrame == -1.0f)
	{
		fSinceLastFrame=0.0f;
	}
	else
	{
		fSinceLastFrame += fDeltaTime;
	}


	if(fSinceLastFrame >= fInterval)
	{
		fSinceLastFrame -= fInterval;

		if(nCurFrame + nDelta == nFrames)
		{
			switch(nMode)
			{
				case ANI_FWD:
				
					break;

				
			}
		}
		else if(nCurFrame + nDelta < 0)
		{
			switch(nMode)
			{
				case ANI_REV:
					bPlaying = false;
					break;
			}
		}

		if(bPlaying) 
		{
			SetFrame(nCurFrame+nDelta);
		}
	}
}
//���õ�ǰ֡Ӧ��ȡ�ķ�ͼƬ
void CAnimationSprite::SetFrame(int n)
{
	int tx1, ty1;

	int ncols = nTexWidth / width;


	n = n % nFrames;
	

	if(n < 0) n = nFrames + n;
	nCurFrame = n;

	// calculate texture coords for frame n
	ty1 = ty;
	//tx += width;;
	tx1 = txStart + n*width;
	//tx1 = tx;
	if(tx1 > nTexWidth - width)
	{
		n -= (nTexWidth -tx) / width;
		tx1 = width * (n%ncols);
		ty1 += height * (1 + n/ncols);
	}

	SetTexPos(tx1,ty1);
}
void CAnimationSprite::SetTexturePos(int tx,int ty)
{
	this->tx = tx;
	this->ty = ty;
}
//���þ���ͼƬ
void CAnimationSprite::SetTexture(LPDIRECT3DTEXTURE9 tex)
{
	CSprite::SetTexture(tex);
}
void CAnimationSprite::SetTexture(LPDIRECT3DTEXTURE9 tex,D3DXVECTOR3 vPos,int w,int h,int tx,int ty)
{
	CSprite::SetTexture(tex);
	this->tx = tx;
	this->ty = ty;
	this->width = w;
	this->height = h;
	this->vPos;
}

