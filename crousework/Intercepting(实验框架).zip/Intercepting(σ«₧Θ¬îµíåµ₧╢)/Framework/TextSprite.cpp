#include "TextSprite.h"

CTextSprite::CTextSprite(
						 LPDIRECT3DDEVICE9		pD3DDevice,			
						 D3DXVECTOR3			vPos,
						 LPTSTR pFontFace, 
						 int nHeight, 
						 bool fBold, 
						 bool fItalic, 
						 bool fUnderlined,
						 D3DCOLOR rgbFontColor
)
{
	this->pD3DDevice = pD3DDevice;
	this->vPos = vPos;
	this->rgbFontColor = rgbFontColor;
	this->pText = NULL;
	this->pFont = NULL;
	this->nBufferSize = 0;

	D3DXCreateFont(pD3DDevice, nHeight, 0, fBold?FW_BOLD:FW_NORMAL, 0, fItalic?1:0,DEFAULT_CHARSET,0,0,0,pFontFace, &pFont);
}

CTextSprite::~CTextSprite(void)
{
	SafeRelease(pFont);
	if (pText)
	{
		delete[] pText;
	}
}


void CTextSprite::Render()
{
	if (this->pText == NULL)
	{
		return;
	}

	RECT Rect;

	Rect.left = vPos.x;
	Rect.top = vPos.y;
	Rect.right = 0;
	Rect.bottom = 0;

	pFont->DrawText(NULL,pText, -1, &Rect, DT_CALCRECT, 0);			//Calculate the size of the rect needed
	pFont->DrawText(NULL,pText, -1, &Rect, DT_LEFT, rgbFontColor);	//Draw the text
}


void CTextSprite::SetText(const LPTSTR pStr)
{
	int len;
	len = _tcslen(pStr) + 1;

	if (pText)
	{
		if (nBufferSize < len)
		{
			delete[] pText;
			pText = new TCHAR[len];
		}
	}
	else
	{
		pText = new TCHAR[len];
	}

	CopyMemory(pText,pStr,len * sizeof(TCHAR));
}