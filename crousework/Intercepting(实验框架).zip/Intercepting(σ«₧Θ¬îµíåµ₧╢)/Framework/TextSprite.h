#pragma once
#include "sprite.h"
#include <tchar.h>

class CTextSprite :
	public CSprite
{
public:
	CTextSprite(
		LPDIRECT3DDEVICE9		pD3DDevice,														//3d�豸	
		D3DXVECTOR3					vPos, 															//λ������
		LPTSTR pFontFace = TEXT("Tahoma"), 
		int nHeight = 20, 
		bool fBold = false, 
		bool fItalic = false, 
		bool fUnderlined = false,
		D3DCOLOR rgbFontColor = 0xFFFFFFFF
		);														
	~CTextSprite(void);

	void Render();

	void SetText(const LPTSTR pStr);
	const LPTSTR GetText()
	{
		return pText;
	}

private:
	LPD3DXFONT	pFont;
	D3DCOLOR	rgbFontColor;
	LPTSTR		pText;
	int			nBufferSize;
};
