#include "SpriteManager.h"

CSpriteManager::CSpriteManager(void)
{
}

CSpriteManager::~CSpriteManager(void)
{
	
	list<CSprite *>::iterator ite = spriteList.begin();
	while(ite != spriteList.end())
	{
		delete *ite;
		ite++;
	}
	spriteList.clear();

}
CSpriteManager::CSpriteManager(LPDIRECT3DDEVICE9 pD3DDevice,CResourceManager *pResManager)
{
	this->pD3DDevice = pD3DDevice;
	this->pResManager = pResManager;
	
}
CSprite * CSpriteManager::CreateSpriteNode(	const LPCWSTR	pszResourceName,
											ResourceType	rt,
											D3DXVECTOR3		vPos,
											int				w,
											int				h,
											int				tx,
											int				ty)
{
	if (rt != RES_TEX)
	{
		return NULL;
	}
	ResDesc *pResDesc = pResManager->GetResource(rt,pszResourceName);
	int nWidth = w;
	int nHeight = h;
	
	LPDIRECT3DTEXTURE9 pTexture = (LPDIRECT3DTEXTURE9)pResDesc->dwHandle;
	D3DSURFACE_DESC surfaceDesc;
	pTexture->GetLevelDesc(0,&surfaceDesc);
	
	if (w == 0 || h == 0)
	{
		nWidth = surfaceDesc.Width;
		nHeight = surfaceDesc.Height;

	}
	CSprite *pSprite = new CSprite(pD3DDevice,pszResourceName,pTexture,vPos,nWidth,nHeight,tx,ty);

	spriteList.push_back(pSprite);
	return pSprite;
	
}

CAnimationSprite * CSpriteManager::CreateAnimationSpriteNode(	const LPCWSTR	pszResourceName,
																ResourceType	rt,
																int				nFrames,
																float			nFps,
																D3DXVECTOR3			vPos,
																int				w,
																int				h,
																int				tx,
																int				ty)
{
	if (rt != RES_TEX)
	{
		return NULL;
	}
	ResDesc *pResDesc = pResManager->GetResource(rt,pszResourceName);
	int nWidth = w;
	int nHeight = h;
	LPDIRECT3DTEXTURE9 pTexture = (LPDIRECT3DTEXTURE9)pResDesc->dwHandle;
	D3DSURFACE_DESC surfaceDesc;
	pTexture->GetLevelDesc(0,&surfaceDesc);
	
	if (w == 0 || h == 0)
	{
		nWidth = surfaceDesc.Width;
		nHeight = surfaceDesc.Height;
	}
	CAnimationSprite *pAnimationSprite = new CAnimationSprite(pD3DDevice,pszResourceName,pTexture,vPos,nFrames,nFps,w,h,tx,ty);

	spriteList.push_back(pAnimationSprite);
	
	return pAnimationSprite;
}

CTextSprite * CSpriteManager::CreateTextSpriteNode(D3DXVECTOR3 vPos, LPTSTR pFontFace /*= L"Tahoma"*/, 
												   int nHeight /*= 20*/, 
												   bool fBold /*= false*/, 
												   bool fItalic /*= false*/, 
												   bool fUnderlined /*= false*/, 
												   D3DCOLOR rgbFontColor/* = -1*/)
{
	CTextSprite * pTextSprite = new CTextSprite(pD3DDevice,vPos,pFontFace,nHeight,fBold,fItalic,fUnderlined,rgbFontColor);
	spriteList.push_back(pTextSprite);
	return pTextSprite;
}

void CSpriteManager::DeleteSpriteNode(CSprite *pSprite)
{
	delete pSprite;
	spriteList.remove(pSprite);
}

void CSpriteManager::Render()
{
	for(list<CSprite*>::iterator ite = spriteList.begin();ite != spriteList.end();ite++)
	{
		if ((*ite)->IsVisible())
		{
			(*ite)->Render();
		}
	}
}

void CSpriteManager::Update(float fDeltaTime)
{
	for(list<CSprite*>::iterator ite = spriteList.begin();ite != spriteList.end();ite++)
	{
		(*ite)->Update(fDeltaTime);
	}
}

void CSpriteManager::Release()
{
	for(list<CSprite*>::iterator ite = spriteList.begin();ite != spriteList.end();ite++)
	{
		(*ite)->Release();
	}
}
void CSpriteManager::Restore(LPDIRECT3DDEVICE9 pDevice)
{
	for(list<CSprite*>::iterator ite = spriteList.begin();ite != spriteList.end();ite++)
	{
		LPDIRECT3DTEXTURE9			pTexture;
		pTexture = (LPDIRECT3DTEXTURE9	)(pResManager->GetResource(RES_TEX,(*ite)->GetResName()))->dwHandle ;  
		(*ite)->Restore(pDevice,pTexture);
	}
}