#include "Sprite.h"


CSprite::CSprite()
{
	pD3DDevice = 0;
	bVisible = true;
}
CSprite::~CSprite(void)
{
}
CSprite::CSprite(	LPDIRECT3DDEVICE9			pD3DDevice,																//3d�豸	
					const LPCWSTR				pszName,
					LPDIRECT3DTEXTURE9			pTexture,																//����
					D3DXVECTOR3					vPos,																	//λ������
					int							w,																		//�������
					int							h,																		//����߶�
					int							tx,																		//����x
					int							ty, 
					D3DXVECTOR3					vHotSpot)
{
	this->pTexture = pTexture;
	this->pD3DDevice = pD3DDevice;
	this->width = w;
	this->height = h;
	this->rectSprite.left = vPos.x;
	this->rectSprite.top = vPos.y;
	this->rectSprite.right = vPos.x + w;
	this->rectSprite.bottom = vPos.y + h;
	this->fRotationAngle = 0;
	this->vPos = vPos;
	this->tx = tx;
	this->ty = ty;
	this->vHotSpot = vHotSpot;
	this->bVisible = true;
	pVB = 0;

	Restore(pD3DDevice,pTexture);
	wcscpy(szResName,pszName);
	

}
HRESULT CSprite::Restore(LPDIRECT3DDEVICE9 pDevice,LPDIRECT3DTEXTURE9 pTexture)
{
	this->pTexture = pTexture;
	D3DSURFACE_DESC surfaceDesc;
	pTexture->GetLevelDesc(0,&surfaceDesc);
	nTexWidth = surfaceDesc.Width;
	nTexHeight = surfaceDesc.Height;
	hState = S_OK;
	this->pD3DDevice = pDevice;
	

	float tu = (float)tx / (float)nTexWidth;
	float tv = (float)ty / (float)nTexHeight;

	float fw = (float)width / (float)nTexWidth;
	float fh = (float)height / (float)nTexHeight;

	if (FAILED(pD3DDevice->CreateVertexBuffer(	4 * sizeof(SPRITEVERTEX),
												0,
												D3DFVF_SPRITE,
												D3DPOOL_DEFAULT,

												&pVB,
												NULL)))
	{
		hState = E_FAIL;
		return hState;
	}
	
	SPRITEVERTEX svPlane[] = {0.0f - vHotSpot.x,0.0f + height - vHotSpot.y,0.0f,		D3DCOLOR_XRGB(255,255,255),	tu,tv + fh,
							  0.0f - vHotSpot.x ,0.0f - vHotSpot.y,0.0f,				D3DCOLOR_XRGB(255,255,255),tu,tv,
							  0.0f+width - vHotSpot.x ,0.0f+height - vHotSpot.y,0.0f,	D3DCOLOR_XRGB(255,255,255),		tu + fw,tv + fh,
							  0.0f+width - vHotSpot.x ,0.0f - vHotSpot.y ,0.0f,		D3DCOLOR_XRGB(255,255,255),	tu + fw,tv};

	

	void *pVertex;
	if(FAILED(pVB->Lock(0 ,4 * sizeof(SPRITEVERTEX),&pVertex,0)))
	{
		hState = E_FAIL;
		return hState;
	}
	memcpy(pVertex,svPlane,sizeof(svPlane));
	pVB->Unlock();

	D3DXMatrixIdentity(&matScale);
	D3DXMatrixIdentity(&matRotationZ);
	
	return hState;
}
void CSprite::Render()
{
	if (!pD3DDevice)
	{
		return;
	}
	

	D3DXMatrixIdentity(&matWorld);
	

	D3DXMatrixTranslation(&matTrans,vPos.x ,vPos.y ,vPos.z);

	D3DXMatrixMultiply(&matWorld,&matWorld,&matScale);

	D3DXMatrixMultiply(&matWorld,&matWorld,&matRotationZ);

	D3DXMatrixMultiply(&matWorld,&matWorld,&matTrans);

	pD3DDevice->SetTransform(D3DTS_WORLD,&matWorld);
	
	pD3DDevice->SetFVF(D3DFVF_SPRITE);
	pD3DDevice->SetStreamSource(0,pVB,0,sizeof(SPRITEVERTEX));
	pD3DDevice->SetTexture(0,pTexture);
	
	HRESULT  ret = pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2);
}
void CSprite::Render(D3DXVECTOR3 vPos)
{
	if (!pD3DDevice)
	{
		return;
	}
	this->vPos = vPos;
	Render();
}
bool CSprite::CollideWith(RECT &rect)
{
	RECT rtIntersect;
	return IntersectRect(&rtIntersect,&this->rectSprite,&rect);
}
bool CSprite::CollideWith(CSprite &sprite) 
{
	RECT rtIntersect;
	return IntersectRect(&rtIntersect,&this->rectSprite,sprite.GetSpriteRect());
}

D3DXVECTOR3	 CSprite::GetHotSpot() 
{
	return this->vHotSpot;
}

const RECT *CSprite::GetSpriteRect()
{
	return &rectSprite;
}

void CSprite::SetTexture(LPDIRECT3DTEXTURE9 tex)
{
	this->pTexture = tex;
	pD3DDevice->SetTexture(0,pTexture);
}
void CSprite::SetHotSpot(D3DXVECTOR3 vHotSpot)
{
	this->vHotSpot = vHotSpot;
	PSPRITEVERTEX pVertex;
	if(FAILED(pVB->Lock(0,4 * sizeof(SPRITEVERTEX),(void**)&pVertex,0)))
	{
		hState = E_FAIL;
		return;
	}

	pVertex->x = -vHotSpot.x;
	pVertex->y = height - vHotSpot.y;
	pVertex++;
	pVertex->x = -vHotSpot.x;
	pVertex->y = -vHotSpot.y;
	pVertex++;
	pVertex->x = width - vHotSpot.x;
	pVertex->y = height - vHotSpot.y;
	pVertex++;
	pVertex->x = width - vHotSpot.x;
	pVertex->y = -vHotSpot.y;
	pVB->Unlock();
	

	
}

void CSprite::SetTransform(D3DXMATRIX matTrans)
{
	this->matWorld = matTrans;

}
D3DXMATRIX CSprite::GetTransform()
{
	return matWorld;
}

int CSprite::GetWidth()
{
	return width;
}
int CSprite::GetHeight()
{
	return height;
}
void CSprite::SetPos(D3DXVECTOR3 &vPos)
{
	this->vPos = vPos;
	rectSprite.left = vPos.x - vHotSpot.x;
	rectSprite.top = vPos.y - vHotSpot.y;
	rectSprite.right = rectSprite.left + width;
	rectSprite.bottom = rectSprite.top + height;
}
D3DXVECTOR3 CSprite::GetPos()
{
	return vPos;
}
void CSprite::SetTexPos(int x,int y)
{
	this->tx = x;
	this->ty = y;
	float tu = (float)tx /(float) nTexWidth;
	float tv = (float)ty /(float) nTexHeight;
	float fw = (float)width / (float)nTexWidth;
	float fh = (float)height / (float)nTexHeight;

	PSPRITEVERTEX pVertex;
	if(FAILED(pVB->Lock(0,4 * sizeof(SPRITEVERTEX),(void**)&pVertex,0)))
	{
		hState = E_FAIL;
		return;
	}
	pVertex->tu = tu;
	pVertex->tv = tv + fh;
	pVertex++;
	pVertex->tu = tu;
	pVertex->tv = tv;
	pVertex++;
	pVertex->tu = tu + fw;
	pVertex->tv = tv + fh;
	pVertex++;
	pVertex->tu = tu + fw;
	pVertex->tv = tv;
	pVB->Unlock();


}
void CSprite::Release()
{
	if (pD3DDevice)
	{
		if(pVB)
		{
			pVB->Release();
		}
	}
}
void CSprite::SetBlendMode(int nMode)
{
	this->nBlendMode = nMode;
}


void CSprite::SetVisible(bool bVal)
{
	this->bVisible = bVal;
}
bool CSprite::IsVisible()
{
	return bVisible;
}

void CSprite::SetRotationAngle(float fAngle)															//������ת�Ƕ�					
{
	D3DXMatrixRotationZ(&matRotationZ,fAngle);

}
void CSprite::SetScaleFactor(float sx,float sy,float sz)
{
	fsx = sx;
	fsy = sy;
	fsz = sz;
	D3DXMatrixScaling(&matScale,sx,sy,sz);
	ComputerBoundingBox();
}

const WCHAR *CSprite::GetResName()
{
	return szResName;
}
void CSprite::SetDestRect(float x1,float y1,float w,float h) 
{
	D3DXMatrixScaling(&matScale,(float)w / (float)width,(float)h / (float)height,1.0);
	SetPos(D3DXVECTOR3(x1,y1,0));
}
void CSprite::ComputerBoundingBox()
{
	rectSprite.left = -vHotSpot.x * fsx;
	rectSprite.top = -vHotSpot.y * fsy;
	rectSprite.right = (width - vHotSpot.x ) * fsx;
	rectSprite.bottom = (height - vHotSpot.y ) * fsy;
	rectSprite.left += vPos.x;
	rectSprite.top += vPos.y;
	rectSprite.right += vPos.x;
	rectSprite.bottom += vPos.y;
}

bool CSprite::IsSelected(int x,int y)
{
	bool bRet = false;
	if (x>=rectSprite.left && x <= rectSprite.right  && y >= rectSprite.top && y <= rectSprite.bottom)
	{
		return true;
	}
	return bRet;
	
}
void CSprite::SetColor(DWORD dwColor)
{
	this->dwColor = dwColor;
	PSPRITEVERTEX pVertex;
	if(FAILED(pVB->Lock(0,4 * sizeof(SPRITEVERTEX),(void**)&pVertex,0)))
	{
		hState = E_FAIL;
		return;
	}

	pVertex->dwColor = dwColor;
	pVertex++;
	pVertex->dwColor = dwColor;
	pVertex++;
	pVertex->dwColor = dwColor;
	pVertex++;
	pVertex->dwColor = dwColor;
	pVB->Unlock();
}
DWORD CSprite::GetColor()
{
	return dwColor;
}