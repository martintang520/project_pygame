#include "Resources.h"

CResourceManager::CResourceManager(/*HWND hWnd,*/LPDIRECT3DDEVICE9 pD3DDevice)
{
	//this->hWnd = hWnd;
	//pHead = NULL;
	this->pD3DDevice = pD3DDevice;
}

CResourceManager::~CResourceManager(void)
{
	Release();
	
	/*if (pHead)
	{
		while(pHead)
		{
			PResDesc pNext = pHead->pNext;
			if (pHead->resourceType == RES_TEX)
			{
				LPDIRECT3DTEXTURE9 pTexture = (LPDIRECT3DTEXTURE9)(pHead->dwHandle);
				SafeRelease(pTexture);
			}
			
			delete pHead;
			pHead = pNext;
		}
	}*/
}
const PResDesc CResourceManager::GetResource(ResourceType resType,const LPCWSTR pszResName)
{
	/*PResDesc pNode = pHead;
	while(pNode)
	{
		if (pNode->resourceType == resType)
		{
			if (wcscmp(pNode->szName,pszResName) == 0)
			{
				return pNode;
			}
		}
		pNode =  pNode->pNext;
	}*/
	for(list<PResDesc>::iterator ite = resList.begin();ite != resList.end();ite++)
	{
		if ((*ite)->resourceType == resType)
		{
			if (wcscmp((*ite)->szName,pszResName) == 0)
			{
				return *ite;
			}
		}
	}
	return NULL;
}
void CResourceManager::Restore(LPDIRECT3DDEVICE9	pD3DDevice)
{
	this->pD3DDevice = pD3DDevice;
	for(list<PResDesc>::iterator ite = resList.begin();ite != resList.end();ite++)
	{
		if ((*ite)->resourceType == RES_TEX)
		{
			LPDIRECT3DTEXTURE9 pTexture;
			ResDesc *pResDesc = *ite;
			HRESULT  ret = LoadTexture(pResDesc->szName,pResDesc->szPath,&pTexture);
			pResDesc->dwHandle = (DWORD)pTexture;
		}
	}
}
HRESULT CResourceManager::LoadTexture(const LPCWSTR pszName,const LPCWSTR  pszFile,LPDIRECT3DTEXTURE9 *ppTexture)
{
	if (pD3DDevice)
	{
		/*HRESULT  ret = D3DXCreateTextureFromFile(pD3DDevice,
												pszFile,
												ppTexture);*/
		HRESULT  ret = D3DXCreateTextureFromFileEx(	pD3DDevice,
													pszFile,
													D3DX_DEFAULT_NONPOW2,
													D3DX_DEFAULT_NONPOW2,
													D3DX_DEFAULT,
													0,
													D3DFMT_UNKNOWN,
													D3DPOOL_MANAGED,
													D3DX_DEFAULT,
													D3DX_DEFAULT,
													0,
													0,
													0,
													ppTexture);
		return ret;
	}
	return E_FAIL;

}
HRESULT CResourceManager::LoadTextureFromFile(const LPCWSTR pszName,const LPCWSTR  pszFile)
{
	LPDIRECT3DTEXTURE9 pTexture;
	if (pD3DDevice)
	{
		
		HRESULT  ret = LoadTexture(pszName,pszFile,&pTexture);
		ResDesc *pResDesc = new ResDesc;
		wcscpy(pResDesc->szName,pszName);
		pResDesc->dwHandle = (DWORD)pTexture;
		wcscpy(pResDesc->szPath,pszFile);
		pResDesc->resourceType = RES_TEX;
		resList.push_back(pResDesc);

		return ret;

	}
	return E_FAIL;
}
void CResourceManager::SetDevice(LPDIRECT3DDEVICE9	pD3DDevice)
{
	this->pD3DDevice = pD3DDevice;
}


void CResourceManager::Release()
{
	for(list<PResDesc>::iterator ite = resList.begin();ite != resList.end();ite++)
	{
		if ((*ite)->resourceType == RES_TEX)
		{
			LPDIRECT3DTEXTURE9 pTexture = (LPDIRECT3DTEXTURE9)((*ite)->dwHandle);
			SafeRelease(pTexture);
		}
	}
}
void CResourceManager::ClearResourceList()
{
	Release();
	resList.clear();
}