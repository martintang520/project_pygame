// Font.cpp: implementation of the CFont class.
//
//////////////////////////////////////////////////////////////////////

#include "Font.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFont::CFont(LPDIRECT3DDEVICE9 pD3DDevice, LPCWSTR pFontFace, int nHeight, bool fBold, bool fItalic, bool fUnderlined)
{
	//HFONT hFont;

	this->pD3DDevice = pD3DDevice;
	
	int nWeight = FW_NORMAL;
	DWORD dwItalic = 0;
	DWORD dwUnderlined = 0;

	if(fBold)
	{
		nWeight = FW_BOLD;
	}

	if(fItalic)
	{
		dwItalic = 1;
	}
	pFont = 0;
	D3DXCreateFont(pD3DDevice,nHeight,0,nWeight,0,dwItalic,DEFAULT_CHARSET,0,0,0,pFontFace, &pFont);
	
}

CFont::~CFont()
{
	SafeRelease(pFont);

	
}

void CFont::DrawText(LPCWSTR pText, int x, int y, D3DCOLOR rgbFontColour)
{
	RECT Rect;

	Rect.left = x;
	Rect.top = y;
	Rect.right = 0;
	Rect.bottom = 0;

	pFont->DrawText(NULL,pText, -1, &Rect, DT_CALCRECT, 0);			//Calculate the size of the rect needed
	pFont->DrawText(NULL,pText, -1, &Rect, DT_LEFT, rgbFontColour);	//Draw the text

}
